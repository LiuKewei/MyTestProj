#/bin/bash
source ./env.sh

DEFAULT_CFG=eMBMSAutoTF.cfg
TIME_STAMP=`date +%Y%m%d%H%M%S`
BACKUP_CFG=eMBMSAutoTF.cfg.bak.$TIME_STAMP
# functions
function ttcn_start {
    rm -rf run.log 
    ttcn3_start eMBMSAutoTF $1 | tee -a run.log
    echo "################################################################" | tee -a run.log
    grep "finished. Verdict" run.log | tee -a run.log
    grep "Verdict statistics:" eMBMSAutoTF.-mtc.log | tee -a run.log
    grep "Test execution summary:"  eMBMSAutoTF.-mtc.log | tee -a run.log
    echo "################################################################" | tee -a run.log
}
           
function usage {
   echo "Usage:"
   echo "./run.sh [-l][-f cfg file][-c testcase name][-h]"
   echo "         no parameters: run all test cases in default eMBMSAutoTF.cfg."
   echo "         [-l]:  list out all test case names."
   echo "         [-f other.cfg]:  run all test cases in other.cfg file instead of default eMBMSAutoTF.cfg."
   echo "         [-c testcase name]:  run test case with the specific testcase name."
   echo "         [-h]:  help."   
}

function archive_log {
   LOGDIR=log$TIME_STAMP
   mkdir $LOGDIR
   mv *.log $LOGDIR
}

# main
if [ ! -f eMBMSAutoTF ]
then
    make
fi

if [ $1 = "-l" ]; then
    ./eMBMSAutoTF -l
elif [ $1 = "-h" ]; then
    usage
elif [ $1 = "-f" ]; then
    if [ -f $2 ]; then
        mv $DEFAULT_CFG $BACKUP_CFG
        cp $2 $DEFAULT_CFG
        ttcn_start
        rm -rf $DEFAULT_CFG
        mv $BACKUP_CFG $DEFAULT_CFG
        archive_log
    else
        echo "Config file $2 dose not exist."
        usage
    fi
elif [ $1 = "-c" ]; then
    ttcn_start $2
    archive_log
elif [ $# -eq 0 ]; then
    ttcn_start
    archive_log
else 
    usage
fi

