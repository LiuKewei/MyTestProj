export TTCN_TOP_DIR=/export/ttcn_env
export TTCN_TITAN_PATH=${TTCN_TOP_DIR}/titan/1.8.pl6
export TTCN_OCCI_PATH=${TTCN_TOP_DIR}/occi/11.2
export TTCN_LIBCURL_PATH=${TTCN_TOP_DIR}/libcurl-devel/7.21.7
export TTCN_OPENSSL_PATH=${TTCN_TOP_DIR}/openssl/0.9.8h
export LD_LIBRARY_PATH=${TTCN_TITAN_PATH}/lib:${TTCN_OCCI_PATH}:${LD_LIBRARY_PATH}

