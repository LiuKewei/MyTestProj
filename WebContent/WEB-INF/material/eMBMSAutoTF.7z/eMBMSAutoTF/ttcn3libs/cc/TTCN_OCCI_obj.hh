#include <string.h>
#include <iostream>
#include <vector>

#ifndef _TTCN_OCCI_HH
#define _TTCN_OCCI_HH

enum occi2ttcn_item_type { TYPE_INT, TYPE_FLOAT, TYPE_STR, TYPE_NULL };

struct occi2ttcn_item
{
	occi2ttcn_item_type val_type;
	union 
	{
		int 	int_val;
		float	float_val;
		char*	str_val;
		bool	null_val;
	} val_;
};

typedef std::vector<occi2ttcn_item> occi2ttcn_result;
typedef std::vector<occi2ttcn_result> occi2ttcn_result_set;

void cleanOcci2ttcn(occi2ttcn_result_set p_in);


#endif