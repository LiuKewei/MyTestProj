#include "TTCN_OCCI_obj.hh"

void cleanOcci2ttcn(occi2ttcn_result_set p_in)
{
	occi2ttcn_result_set::iterator occiResultSetItr;
			
	for( occiResultSetItr = p_in.begin(); occiResultSetItr < p_in.end(); occiResultSetItr++)
	{			
		occi2ttcn_result occiResult = *occiResultSetItr;
		occi2ttcn_result::iterator occiResultItr;
		
		for( occiResultItr = occiResult.begin(); occiResultItr < occiResult.end(); occiResultItr++)
		{
			if ( (*occiResultItr).val_type == TYPE_STR )
			{
				delete [] (*occiResultItr).val_.str_val;
			}
		}
	}
}