#!/bin/sh
#eg. 
# ../ttcn3libs/cc/MdfCfg/MdfCfg.sh TwoFRServer fec0::221:28ff:fef0:d1cf fec0::221:28ff:fef0:d6ab 38888 38889 /bmsccontents/ncm/mdf-cp-config.xml /opt/ericsson/bm-sc/mdf-cp/bin/mdf-cp_config_reload.sh
# ../ttcn3libs/cc/MdfCfg/MdfCfg.sh OneFRServer fec0::221:28ff:fef0:d1cf fec0::221:28ff:fef0:d6ab 38888 /bmsccontents/ncm/mdf-cp-config.xml /opt/ericsson/bm-sc/mdf-cp/bin/mdf-cp_config_reload.sh

function modify {
  chmod 755 mod-cp-config.sh
  sh mod-cp-config.sh
}

if [ $1 = "OneFRServer" ]; then
  echo "sed -i -e \"s/<FileRepairServerUrlRootPath>.*<\/FileRepairServerUrlRootPath>/<FileRepairServerUrlRootPath>$6:\/\/[$2]:$3\/bm-sc\/adf-provisioning\/<\/FileRepairServerUrlRootPath>/g\" $5" > mod-cp-config.sh
  modify
elif [ $1 = "TwoFRServers" ]; then
  echo "sed -i -e \"s/<FileRepairServerUrlRootPath>.*<\/FileRepairServerUrlRootPath>/<FileRepairServerUrlRootPath>$6:\/\/[$2]:$3\/bm-sc\/adf-provisioning\/,$6:\/\/[$2]:$4\/bm-sc\/adf-provisioning\/<\/FileRepairServerUrlRootPath>/g\" $5" > mod-cp-config.sh
  modify	
elif [ $1 = "OneRRServer" ]; then
  echo "sed -i -e \"s/<ReceptionReportServerUrlRootPath>.*<\/ReceptionReportServerUrlRootPath>/<ReceptionReportServerUrlRootPath>$6:\/\/[$2]:$3\/bm-sc\/adf-provisioning\/<\/ReceptionReportServerUrlRootPath>/g\" $5" > mod-cp-config.sh
  modify
elif [ $1 = "TwoRRServers" ]; then
  echo "sed -i -e \"s/<ReceptionReportServerUrlRootPath>.*<\/ReceptionReportServerUrlRootPath>/<ReceptionReportServerUrlRootPath>$6:\/\/[$2]:$3\/bm-sc\/adf-provisioning\/,$6:\/\/[$2]:$4\/bm-sc\/adf-provisioning\/<\/ReceptionReportServerUrlRootPath>/g\" $5" > mod-cp-config.sh
  modify
else
  echo "Error Command."
fi

