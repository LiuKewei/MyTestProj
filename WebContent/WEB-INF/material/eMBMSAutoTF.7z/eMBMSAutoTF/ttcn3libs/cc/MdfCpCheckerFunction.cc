#include <time.h>
#include <sys/types.h>
#include <fstream>
#include <iostream>
#include <cstring>

#include <unistd.h>  
#include <stdlib.h>  
#include <stdio.h>  
#include <string.h>
#include <ctype.h>

#include "MdfCpCheckerFunctions.hh"
#include "ExternalFunctions.hh"

#define INIT_SIZE 2048

using namespace std;
namespace MdfCpCheckerFunctions {
  
  // excute SQL Query, call DatabaseOperator, get the recordset in result_tmp_file
  CHARSTRING ext__f__executeQuerySQL( const CHARSTRING& db_address, 
                                      const CHARSTRING& user_name, 
                                      const CHARSTRING& passwd, 
                                      const CHARSTRING& sql_statement, 
                                      const CHARSTRING& result_tmp_file )
  {
    const char* ret = "false";
    char clean_file[INIT_SIZE] = "rm -rf ";
    strcat(clean_file, (const char *)result_tmp_file);
    FILE *clean_file_pp = popen (clean_file, "r");
    if (clean_file_pp == NULL)
    {
      pclose(clean_file_pp);
      printf ("Can not clean result_tmp_file %s.\n", (const char *)result_tmp_file);
      return CHARSTRING(strlen(ret), ret);
    }  
    pclose(clean_file_pp);
    
    char db_execute[INIT_SIZE] = "../generated/DatabaseOperator ";
    strcat(db_execute, (const char *)db_address);
    strcat(db_execute, " ");
    strcat(db_execute, (const char*)user_name);
    strcat(db_execute, " ");
    strcat(db_execute, (const char*)passwd);
    strcat(db_execute, " \"");
    strcat(db_execute, (const char*)sql_statement);
    strcat(db_execute, "\" ");
    strcat(db_execute, (const char*)result_tmp_file);
    db_execute[strlen(db_execute)] = '\0';
    printf ("\nEXECUTE DB OPERATION BY COMMAND: \"%s\"\n\n", db_execute);
    FILE *pp = popen (db_execute, "w");
    if (pp == NULL)
    {
      pclose(pp);
      printf ("Can not execute DatabaseOperator\n");
      return CHARSTRING(strlen(ret), ret);
    }  
    pclose(pp);
    char record[INIT_SIZE/2] = "";
    memset( db_execute, 0, INIT_SIZE );
    
    
    char *datas = (char *)malloc(INIT_SIZE * sizeof(char));
    if (datas == NULL)
    {
      printf ("memory malloc fail.\n");
      return CHARSTRING(strlen(ret), ret);
    }
    int current_len = 0;
    int malloc_cnt = 1;
    
    if ( access((const char *)result_tmp_file, R_OK) != 0 )
    {
      printf ("DB result %s is not existed.\n", (const char*)result_tmp_file);
      return CHARSTRING(strlen(ret), ret);
    }
    
    FILE *fp = fopen ((const char*)result_tmp_file, "r");
    if (fp == NULL)
    {
      fclose(fp);
      printf ("Can not open DB result %s.\n", (const char*)result_tmp_file);
      return CHARSTRING(strlen(ret), ret);
    }
    while ( fgets(record, INIT_SIZE/2, fp) != NULL )
    {
      strcat(datas, record);
      current_len = strlen(datas);
      if ( current_len >= (INIT_SIZE/2*malloc_cnt) && current_len <= (INIT_SIZE*malloc_cnt) )
      {
        malloc_cnt++;
        datas = (char *)realloc(datas, (malloc_cnt * INIT_SIZE) * sizeof(char));
        if (datas == NULL)
        {
          printf ("memory realloc fail.\n");
          return CHARSTRING(strlen(ret), ret);
        }
      }
    }
    fclose(fp);
    if (current_len == 0)
    {
      free(datas);
      datas = NULL;
      return CHARSTRING(0, "");
    }
    
    TTCN_Buffer buf;
    buf.put_cs(CHARSTRING(current_len, datas));
    
    free(datas);
    datas = NULL;
    
    return CHARSTRING(buf.get_len(), (const char*)buf.get_data());
    
  }

}
