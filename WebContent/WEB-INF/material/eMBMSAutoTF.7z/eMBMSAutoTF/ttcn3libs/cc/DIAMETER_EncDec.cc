///////////////////////////////////////////////////////////////////////////////
//                                                                           //
// Copyright Test Competence Center (TCC) ETH 2005                           //
//                                                                           //
// The copyright to the computer  program(s) herein  is the property of TCC. //
// The program(s) may be used and/or copied only with the written permission //
// of TCC or in accordance with  the terms and conditions  stipulated in the //
// agreement/contract under which the program(s) has been supplied.          //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
//
//  File:               DIAMETER_EncDec.cc
//  Description:	Encoder/Decoder and external functions for DPMG
//  Rev:                <RnXnn>
//  Prodnr:             CNL 113 462
//  Updated:            2007-03-08
//  Contact:            http://ttcn.ericsson.se
///////////////////////////////////////////////

#include "DIAMETER_Types.hh"
#include <sys/timeb.h>

namespace DIAMETER__Types{
static const unsigned char os_h_or_e_id_octets[] = { 0, 0, 0, 0 };
static const OCTETSTRING os_h_or_e_id_oct(4, os_h_or_e_id_octets);


OCTETSTRING f__DIAMETER__genHopByHop()
{
  OCTETSTRING ret = os_h_or_e_id_oct;
  timeb precise;                        // requires <sys/timeb.h>
  if ( ftime(&precise) != -1 ) {
    srand48(precise.time + precise.millitm);
    ret = int2oct(lrand48(),4);
  }
  else TTCN_warning("f_DIAMETER_genHopByHop() returns with \'00000000\'O");
  return ret;
}

OCTETSTRING f__DIAMETER__genEndToEnd()
{
  OCTETSTRING ret = os_h_or_e_id_oct;
  timeb precise;                        // requires <sys/timeb.h>
  if ( ftime(&precise) != -1 ) {
    srand48(precise.time + precise.millitm);
    int l_value = (precise.time << 20) + (lrand48() >> 12);
    if (l_value < 0) l_value *= -1;
    ret = int2oct(l_value,4);
  }
  else TTCN_warning("f_DIAMETER_genHopByHop() returns with \'00000000\'O");
  return ret;
}

OCTETSTRING f__DIAMETER__Enc(const PDU__DIAMETER& pl__pdu)
{
  PDU__DIAMETER* par=NULL;
  
  if (pl__pdu.hop__by__hop__id() == os_h_or_e_id_oct){
    par = new PDU__DIAMETER(pl__pdu);
    par->hop__by__hop__id() = f__DIAMETER__genHopByHop();
  }
  
  if (pl__pdu.end__to__end__id() == os_h_or_e_id_oct){
    if(par==NULL) par = new PDU__DIAMETER(pl__pdu);
    par->end__to__end__id() = f__DIAMETER__genEndToEnd();
  }
  
  TTCN_Buffer buf;
  TTCN_EncDec::error_type_t err;
  buf.clear();
  TTCN_EncDec::clear_error();
  TTCN_EncDec::set_error_behavior(TTCN_EncDec::ET_ALL, TTCN_EncDec::EB_WARNING);
  if(par)
    par->encode(PDU__DIAMETER_descr_, buf, TTCN_EncDec::CT_RAW);
  else 
    pl__pdu.encode(PDU__DIAMETER_descr_, buf, TTCN_EncDec::CT_RAW);
  err = TTCN_EncDec::get_last_error_type();
  if(err != TTCN_EncDec::ET_NONE)
    TTCN_warning("Encoding error: %s\n", TTCN_EncDec::get_error_str());
  delete par;
  return OCTETSTRING(buf.get_len(), buf.get_data());
}

PDU__DIAMETER f__DIAMETER__Dec(const OCTETSTRING& pl__oct) 
{
  PDU__DIAMETER pdu;
  TTCN_Buffer buf;
  TTCN_EncDec::error_type_t err;
  TTCN_EncDec::clear_error();
  buf.clear();
  buf.put_os(pl__oct);
  TTCN_EncDec::set_error_behavior(TTCN_EncDec::ET_ALL, TTCN_EncDec::EB_WARNING);
  pdu.decode(PDU__DIAMETER_descr_, buf, TTCN_EncDec::CT_RAW);
  err = TTCN_EncDec::get_last_error_type();
  if(err != TTCN_EncDec::ET_NONE)
    TTCN_warning("Decoding error: %s\n", TTCN_EncDec::get_error_str());
  return pdu;
}
}
TTCN_Module DIAMETER_EncDec("DIAMETER_EncDec", __DATE__, __TIME__);
