#include <iostream>
#include <string.h>

#include "TTCN_OCCI_obj.hh"

class Database
{
  public:
    Database();
    ~Database();   
    bool connect(const char* conn_string, const char* user, const char* pwd);    
    void disconnect();
    bool selectSQL(const char* sqlstr, occi2ttcn_result_set& result_set );
 
  private:    
    bool _connected; 
};
