#include <occi.h>
#include <ocidem.h>
#include <ocidfn.h>
#include "TTCN_OCCI_wrapper.hh"

using namespace oracle::occi;
using namespace std;

static Environment *env;
static Connection  *conn;

Database::Database()
{
	_connected = false;
}

Database::~Database()
{
}

bool Database::connect(const char* conn_string, const char* user, const char* pwd)
{
	try
	{
		this->disconnect();
		cout << "start to conneting " << endl;
  
		env = Environment::createEnvironment(Environment::DEFAULT);
		cout << "create env successfully " << endl;
  
		conn = env->createConnection(user, pwd, conn_string);  
		cout << "connected to db successfully " << endl;

	  	if( NULL != conn ) 
	  	{
	    		_connected = true;
  		}
	}
	catch(SQLException ex)
	{
  		cout<< ex.getMessage() << endl;
	}
  
  	return _connected;
}

void Database::disconnect()
{
	if( _connected )
	{
		env->terminateConnection(conn);
		Environment::terminateEnvironment(env);
		_connected = false;
    
		cout << "disconnect to db successfully " << endl;
	}
}

bool Database::selectSQL(const char* sqlstr, occi2ttcn_result_set& result_set )
{
  	if ( _connected )
  	{
	    	Statement *stmt = conn->createStatement(sqlstr);
    		try
    		{
      			ResultSet *res = stmt->executeQuery();

			vector<MetaData> listMetaData = res->getColumnListMetaData();
			int numCols = listMetaData.size();		

			cout << "column number " << numCols << endl;
			
      			while(res->next())
      			{
				occi2ttcn_result result;
				result.resize(numCols);

				for(int i = 0; i < numCols; i++)
				{
					int colIdx = i + 1;

					if(res->isNull(colIdx))
					{
						result.at(i).val_type = TYPE_NULL;
						result.at(i).val_.null_val = true;	
						continue;	
					}

					int colDataType = listMetaData[i].getInt(MetaData::ATTR_DATA_TYPE);

					switch(colDataType)
					{
						case (SQLT_CHR):
						case (SQLT_DAT):
						case (SQLT_TIMESTAMP):
						{
							result.at(i).val_type = TYPE_STR;
						
							string aStrval;
							
							if( SQLT_CHR == colDataType )
							{
								aStrval =  res->getString(colIdx);
							}
							else if( SQLT_DAT == colDataType )
							{
								aStrval =  res->getDate(colIdx).toText();
							}
							else if( SQLT_TIMESTAMP == colDataType )
							{
								aStrval =  res->getTimestamp(colIdx).toText("yyyymmddhhmisstzh", 0);
							}
														
							result.at(i).val_.str_val = new char [aStrval.size() + 1];
							strcpy(result.at(i).val_.str_val, aStrval.c_str());
							
							break;
						}
						case (SQLT_NUM):
						{
							int precision = listMetaData[i].getInt(MetaData::ATTR_SCALE);

							if(	0 == precision)						
							{
								result.at(i).val_type = TYPE_INT;
								result.at(i).val_.int_val = int(res->getNumber(colIdx));
							}
							else
							{
								result.at(i).val_type = TYPE_FLOAT;
								result.at(i).val_.float_val = float(res->getNumber(colIdx));							
							}
							
							break;					
						}				
						default:
						{
							cout << "unfinished code for " << colDataType << endl;
							
							break;
						}
					}
				
				} 

					result_set.push_back(result);
      			}

			stmt->closeResultSet(res);
			conn->terminateStatement(stmt);
    		}
    		catch(SQLException ex)
   	 	{
      			cout<< ex.getMessage() << endl;
      			return false;
    		}
		
	}

	return true;
}

/*
int main()
{
	occi2ttcn_result_set myResult;
	Database myDatabase = Database();

	myDatabase.connect("10.170.65.221:1521/bmsc", "xiudongzhang", "xiudongzhang");
	
	myDatabase.selectSQL("select * from T_Test", myResult);

	//myDatabase.selectSQL("select * from T_Test", myResult);
	
	myDatabase.disconnect();

	cout << "aaaaaaaaaaaaa" << endl;

	occi2ttcn_result_set::iterator myResult_it;
	occi2ttcn_result::iterator row_it;
	for( myResult_it = myResult.begin(); myResult_it < myResult.end(); myResult_it++)
	{
		occi2ttcn_result row_data = *myResult_it;
		for( row_it = row_data.begin(); row_it < row_data.end(); row_it++)
		{
			if ( (*row_it).val_type == TYPE_STR )
			{
				cout << "a " << (*row_it).val_.str_val << endl;
			}
			else if ( (*row_it).val_type == TYPE_FLOAT )
			{
				cout <<  "b " <<(*row_it).val_.float_val << endl;
			}
			else if ( (*row_it).val_type == TYPE_INT )
			{
				cout <<  "c " <<(*row_it).val_.int_val << endl;
			}			
			else if ( (*row_it).val_type == TYPE_NULL )
			{
				cout <<  "d NULL" << endl;
			}
			else
			{

			}
		}

	}
			
}*/





