#include <time.h>
#include <sys/types.h>
#include <fstream>
#include <iostream>
#include <cstring>

#include <unistd.h>  
#include <stdlib.h>  
#include <stdio.h>  
#include <string.h>
#include <ctype.h>
#include <assert.h>


#include "AdfCheckerFunctions.hh"

/*  for     ext__f__check__payload   */
#define DIGIT syms_in_sbn
#define CAL_SYMS(DIGIT) ((int)DIGIT[3]*(256e3)+(int)DIGIT[2]*(256e2)+(int)DIGIT[1]*(256)+(int)DIGIT[0])

static unsigned char DIGIT[4];

static int payload_body_len = 0;
static int current_checked_datas = 0;
static const unsigned char * payload_body_data;
static const char * ue_req_sbn_and_esi;

static int symbol_num = 0;
static int sbn_index = 0;
static int esi_index = 0;

#define REPOSITION(x, x_start_idx) ( x = (int)(payload_body_data[current_checked_datas+x_start_idx])*256+(int)(payload_body_data[current_checked_datas+x_start_idx+1]) )

#define CAL_CHECKED_DATAS(); current_checked_datas += (symbol_num*symbol_size+6); \
                             if (current_checked_datas < payload_body_len)             /* if remaining payloads need to check */ \
                             { \
                               REPOSITION(symbol_num, 0); \
                               REPOSITION(sbn_index, 2);  \
                               REPOSITION(esi_index, 4);  \
                             }
/*  for     ext__f__check__payload   */


using namespace std;
namespace AdfCheckerFunctions {

  int get_char_index (char * src, char c)
  {
    for (unsigned int i = 0; i < strlen(src); i++)
    {
      if (src[i] == c)
      {
        return i;
      }
    }
    return -1;
  }
  
  bool compare_payload_with_encfile(FILE *idx_stream, 
                                    FILE *enc_stream,
                                    int symbol_size,
                                    int init_src_syms,
                                    int intermediate_sbn_id)
  {
    int tot_esi, src_esi, repair_esi;
    fseek(idx_stream, sbn_index*12, SEEK_CUR);
    
    fread(DIGIT, 4, 1, idx_stream);
    tot_esi = CAL_SYMS(DIGIT);
    printf ("tot_esi number : %d\n",  tot_esi);
    
    fread(DIGIT, 4, 1, idx_stream);
    src_esi = CAL_SYMS(DIGIT);
    printf ("src_esi number : %d\n",  src_esi);
    
    fread(DIGIT, 4, 1, idx_stream);
    repair_esi = CAL_SYMS(DIGIT);
    printf ("repair_esi number : %d\n",  repair_esi);
    
    printf ("requst symbol number : %d\n",  symbol_num);
    unsigned char enc_payload[symbol_num*symbol_size];
    if (sbn_index > intermediate_sbn_id) 
    {
      fseek(enc_stream, ( (intermediate_sbn_id*init_src_syms)+(sbn_index-intermediate_sbn_id)*src_esi+esi_index )*symbol_size, SEEK_CUR );
    }
    else
    {
      fseek(enc_stream, (sbn_index*src_esi+esi_index)*symbol_size, SEEK_CUR);
    }
    
    fread(enc_payload, symbol_num*symbol_size, 1, enc_stream);
    
    for (int i=0; i< symbol_num*symbol_size; i++)
    {
      if (payload_body_data[current_checked_datas+i+6] != enc_payload[i])
      {
        printf ("The byte index of %d from SBN %d and ESI %d in HTTP payload is different with encoded file!!\n",  i, sbn_index, esi_index );
        printf ("in payload_body_data is : %x\n",  payload_body_data[i+6]);
        printf ("in enc_file is : %x\n",  enc_payload[i]);
        return false;
      }
    }
    return true;
  }


  bool check_esi_in_sbn (FILE *r_stream, 
                         FILE *enc_stream,
                         int symbol_size,
                         int init_src_syms,
                         int intermediate_sbn_id,
                         int and_count,
                         int total_SBN,
                         int range_of_esi,
                         char * digit_str,
                         int esi_digit,
                         char *esi_str)
  {
    char symbol_num_str[1024];
    if ( (range_of_esi = get_char_index (digit_str, '+')) == -1 && (range_of_esi = get_char_index (digit_str, '-')) == -1 )
    {
      if (esi_digit != esi_index)
      {
        printf("ESI number with payload in http response error, Except %d, Received %d .", esi_digit, esi_index);
        return false;
      }
      if (symbol_num != 1)
      {
        printf("Symbol number with payload in http response error, Except %d, Received %d Symbols.", 1, symbol_num);
        return false;
      }
      
      bool compare_ret = compare_payload_with_encfile(r_stream, enc_stream, symbol_size, init_src_syms, intermediate_sbn_id);
      assert(compare_ret);
    }  // end no special notation of ESI
    else if ( (range_of_esi = get_char_index (digit_str, '+')) != -1 )
    {
      strncpy( symbol_num_str, digit_str+range_of_esi+1, strlen(digit_str)-range_of_esi-1 );
      symbol_num_str[strlen(digit_str)-range_of_esi-1] = '\0';
      int symbol_num_digit = strtol(symbol_num_str,NULL,10);
      if (symbol_num_digit != symbol_num-1)
      {
        printf("Symbol number with payload in http response error, Except %d, Received %d Symbols.", (symbol_num_digit+1), symbol_num);
        return false;
      }
      strncpy( esi_str, digit_str, range_of_esi );
      esi_str[range_of_esi] = '\0';
      esi_digit = strtol(esi_str,NULL,10);
      if (esi_digit != esi_index)
      {
        printf("ESI number with payload in http response error, Except %d, Received %d .", esi_digit, esi_index);
        return false;
      }
      bool compare_ret = compare_payload_with_encfile(r_stream, enc_stream, symbol_size, init_src_syms, intermediate_sbn_id);
      assert(compare_ret);
    }  // end '+'
    else if ( (range_of_esi = get_char_index (digit_str, '-')) != -1 )
    {
      strncpy( symbol_num_str, digit_str+range_of_esi+1, strlen(digit_str)-range_of_esi-1 );
      symbol_num_str[strlen(digit_str)-range_of_esi-1] = '\0';
      int symbol_num_digit = strtol(symbol_num_str,NULL,10);
      
      strncpy( esi_str, digit_str, range_of_esi );
      esi_str[range_of_esi] = '\0';
      esi_digit = strtol(esi_str,NULL,10);
      
      if (symbol_num_digit-esi_digit != symbol_num-1)
      {
        printf("Symbol number with payload in http response error, Except %d, Received %d Symbols.", (symbol_num_digit-esi_digit+1), symbol_num);
        return false;
      }
      if (esi_digit != esi_index)
      {
        printf("ESI number with payload in http response error, Except %d, Received %d .", esi_digit, esi_index);
        return false;
      }
      bool compare_ret = compare_payload_with_encfile(r_stream, enc_stream, symbol_size, init_src_syms, intermediate_sbn_id);
      assert(compare_ret);
    }  // end '-'
    else
    {
      printf("The ESI expression error : \"%s\", only supported '=' ',' '+' '-' ", digit_str);
      return false;
    }
    
    return true;
  }


  bool check_all_kind_of_sbn (FILE *r_stream, 
                              FILE *enc_stream,
                              int symbol_size,
                              int init_src_syms,
                              int intermediate_sbn_id,
                              int and_count,
                              int total_SBN)
  {
    char *token;
    char digit_str[1024];
    char esi_str[1024];
    int range_of_esi = 0;
    int range_of_sbn = 0;
    bool check_esi_ret = false;
    
    printf("\n");
    printf("Start check payload with each SBN in loop.\n\n ");
    for (int i = 0; i < and_count+1; i++ )
    {
      fseek(r_stream, 16L, SEEK_SET);
      fseek(enc_stream, 0L, SEEK_SET);   // resume env
      token = strsep ( (char **)&ue_req_sbn_and_esi, "&" );
      
      if (token[0] == 'S') 
      { 
        printf("\n");
        printf("request SBN and ESI : %s\n", token);
        int equal = get_char_index (token, '=');
        assert(equal != -1);
        int semicolon = get_char_index (token, ';');
        if (semicolon == -1)
        {
          //not supported '+' in SBN expression like : &SBN=13+15
          if ( (range_of_sbn = get_char_index (token, '-')) != -1 )
          {
            char max_sbn[1024];
            strncpy( max_sbn, token+range_of_sbn+1, strlen(token)-range_of_sbn-1 );
            max_sbn[strlen(token)-range_of_sbn-1] = '\0';
            int max_sbn_range = strtol(max_sbn,NULL,10);
            assert( total_SBN >= (max_sbn_range+1) );
            
            strncpy( digit_str, token+equal+1, range_of_sbn-equal-1 );
            digit_str[range_of_sbn-equal-1] = '\0';
            int sbn_digit = strtol(digit_str,NULL,10);
            int sbn_cnt = max_sbn_range - sbn_digit + 1;
            for (int sbn_i = 0; sbn_i < sbn_cnt; sbn_i++)
            {
              fseek(r_stream, 16L, SEEK_SET);
              fseek(enc_stream, 0L, SEEK_SET);   // resume env
              assert ( (sbn_digit+sbn_i) == sbn_index );
              printf("\nremaining SBN=%d-%d\n", sbn_digit+sbn_i, max_sbn_range);
              bool compare_ret = compare_payload_with_encfile(r_stream, enc_stream, symbol_size, init_src_syms, intermediate_sbn_id);
              assert(compare_ret);
              check_esi_ret = compare_ret;
              CAL_CHECKED_DATAS();
            }
            printf("\n ... PASS \n----------------\n");
            continue;
          }
          else if ((range_of_sbn = get_char_index (token, '+')) != -1)
          {
            printf("not supported '+' in SBN expression like : &SBN=13+15.\n");
            return check_esi_ret;
          }
          else
          {
            strncpy( digit_str, token+equal+1, strlen(token)-equal-1 );
            digit_str[strlen(token)-equal-1] = '\0';
            int sbn_digit = strtol(digit_str,NULL,10);
            assert( total_SBN >= (sbn_digit+1) );
            if (sbn_digit != sbn_index)
            {
              printf("SBN number with payload in http response error, Except %d, Received %d .", sbn_digit, sbn_index);
              return check_esi_ret;
            }
            
            bool compare_ret = compare_payload_with_encfile(r_stream, enc_stream, symbol_size, init_src_syms, intermediate_sbn_id);
            assert(compare_ret);
            check_esi_ret = compare_ret;
          }
          
          printf("\n ... PASS \n----------------\n");
          
        }  // end only SBN (with out ESI)
        else
        {
          strncpy( digit_str, token+equal+1, semicolon-equal-1 );
          digit_str[semicolon-equal-1] = '\0';
          int sbn_digit = strtol(digit_str,NULL,10);
          if (sbn_digit != sbn_index)
          {
            printf("SBN number with payload in http response error, Except %d, Received %d .", sbn_digit, sbn_index);
            return check_esi_ret;
          }
          int esi_str_index = semicolon+1;
          int esi_str_len = strlen(token)-esi_str_index;
          strncpy( esi_str, token+esi_str_index, esi_str_len );
          esi_str[esi_str_len] = '\0';
          
          equal = get_char_index (esi_str, '=');
          strncpy( digit_str, esi_str+equal+1, strlen(esi_str)-equal-1 );
          digit_str[strlen(esi_str)-equal-1] = '\0';
          int esi_digit = 0;
          if ( (range_of_esi = get_char_index (digit_str, ',')) != -1 )
          {
            int comma_count = 0;  // the count of ','
            int comma_str_len = strlen(digit_str);
            for(int comma_i = 0; comma_i < comma_str_len; comma_i++)
            {
              if (digit_str[comma_i] == ',')
              {
                comma_count++;
              }
            }
            char *esi_token;
            char *esi_charstr = (char *)malloc((comma_str_len+1) * sizeof(char));
            if (esi_charstr == NULL)
            {
              printf ("memory malloc fail.\n");
              return check_esi_ret;
            }
            memcpy(esi_charstr, digit_str, comma_str_len+1);
            char * free_esi = esi_charstr;// free flag
            for (int comma_i = 0; comma_i < comma_count+1; comma_i++)
            {
              fseek(r_stream, 16L, SEEK_SET);
              fseek(enc_stream, 0L, SEEK_SET);// resume env
              printf("\nremaining ESI=%s\n",esi_charstr);
              esi_token = strsep ( (char **)&esi_charstr, "," );
              esi_digit = strtol(esi_token,NULL,10);
              assert( esi_index == esi_digit );
              memset(digit_str, 0, sizeof(digit_str));
              strncpy(digit_str, esi_token, strlen(esi_token));
              check_esi_ret = check_esi_in_sbn (r_stream, enc_stream, symbol_size,init_src_syms, intermediate_sbn_id, 
                                                and_count, total_SBN, range_of_esi,digit_str, esi_digit, esi_str);
              assert(check_esi_ret);
              CAL_CHECKED_DATAS();
            }
            free(free_esi);
            printf("\n ... PASS \n----------------\n");
            continue;
          }  // end ','
          else
          {
            esi_digit = strtol(digit_str,NULL,10);
            check_esi_ret = check_esi_in_sbn (r_stream, enc_stream, symbol_size,init_src_syms, intermediate_sbn_id, 
                                              and_count, total_SBN, range_of_esi,digit_str, esi_digit, esi_str);
            assert(check_esi_ret);
            printf("\n ... PASS \n----------------\n");
          }
          
        }
        CAL_CHECKED_DATAS();
      }
      
    }
    return check_esi_ret;
  }


  BOOLEAN ext__f__check__payload (const OCTETSTRING& src_body, const CHARSTRING& sbn_and_esi, 
                                  const INTEGER& symbol_size, const CHARSTRING& md5_str,
                                  const CHARSTRING& repair_file_path)
  {
    printf ("\n");
    printf ("Payload checking ... \n\n");
    TTCN_Buffer buf;
    buf.put_os(src_body);
    
    /* init data */
    payload_body_len = buf.get_len();
    payload_body_data = (const unsigned char*)buf.get_data();
    
    ue_req_sbn_and_esi = (const char*)sbn_and_esi;
    printf ("SBN_and_ESI : %s\n", ue_req_sbn_and_esi);
    
    /* deal data */
    symbol_num = (int)(payload_body_data[0])*256+(int)(payload_body_data[1]);
    sbn_index  = (int)(payload_body_data[2])*256+(int)(payload_body_data[3]);
    esi_index  = (int)(payload_body_data[4])*256+(int)(payload_body_data[5]);
    
    int and_count = 0;  // the count of '&'
    int temp_len = strlen(ue_req_sbn_and_esi);
    for(int i = 0; i < temp_len; i++)
    {
      if (ue_req_sbn_and_esi[i] == '&')
      {
        and_count++;
      }
    }
    
    /* get idx file */
    FILE   *r_stream;
    FILE   *p_stream;
    FILE   *enc_stream;
    char search_file_path[1024] = "find ";
    strcat (search_file_path, repair_file_path);
    strcat (search_file_path, " -name ");
    strcat(search_file_path, (const char*)md5_str);
    p_stream = popen (search_file_path, "r");
    if (p_stream == NULL)
    {
      pclose(p_stream);
      return false;
    }
    
    memset( search_file_path, 0, 1024 );
    fgets(search_file_path, 1024, p_stream);
    pclose(p_stream);   // close the pipe stream
    if ( !strcmp (search_file_path, "") ) 
    {
    	printf ("ERROR :Can not find content repair directory, please check your config file! Make sure you have mount the content repair directory to the tool hoster\n");
    	return false;
    }
    printf ("search_file_path : %s\n", search_file_path);
    char index_file_path[1024];
    strncpy( index_file_path, search_file_path, strlen(search_file_path)-36-1 );
    index_file_path[strlen(search_file_path)-36-1] = '\0';
    strcat(index_file_path, "index");
    printf ("index_file_path : %s\n", index_file_path);
    
    /* open index file to get the total SBN and total symbol number in each SBN */
    r_stream = fopen( index_file_path, "rb");
    fseek(r_stream, 0L, SEEK_END);
    long int index_file_len = ftell(r_stream);
    fseek(r_stream, 16L, SEEK_SET);
    
    /* need to find which SBN deducting the next SBN is 1 */
    int total_SBN = (index_file_len - 16) / 12;
    printf ("\nTotal SBN counts : %d\n\n", total_SBN);
    
    unsigned char intermediate_sbn[12];
    fread(DIGIT, 4L, 1, r_stream);
    int init_total_syms = CAL_SYMS(DIGIT);
    fread(DIGIT, 4L, 1, r_stream);
    int init_src_syms = CAL_SYMS(DIGIT);
    int intermediate_sbn_id = 0;
    fseek(r_stream, 16L, SEEK_SET);
    for(int i=0; i < total_SBN; i++)
    {
      fread(intermediate_sbn, 12L, 1, r_stream);
      int temp_syms = (int)intermediate_sbn[3]*(256e3)+(int)intermediate_sbn[2]*(256e2)+(int)intermediate_sbn[1]*(256)+(int)intermediate_sbn[0];
      if (init_total_syms == temp_syms+1) 
      {
        intermediate_sbn_id = i;
        break;
      }
    }
    
    char enc_file_path[1024];
    strncpy( enc_file_path, search_file_path, strlen(search_file_path)-36-1 );
    enc_file_path[strlen(search_file_path)-36-1] = '\0';
    strcat(enc_file_path, "content.enc");
    printf ("enc_file_path : %s\n\n", enc_file_path);
    //printf ("segment number : %d\n", intermediate_sbn_id);
    
    /* open encoded file to check the payload */
    enc_stream = fopen( enc_file_path, "rb");
    
    bool check_ret = check_all_kind_of_sbn(r_stream, enc_stream, symbol_size, init_src_syms, intermediate_sbn_id, and_count, total_SBN);
    assert(check_ret);
    
    printf ("\n");
    printf ("Payload check done. \n\n");
    
    fclose(r_stream);
    fclose(enc_stream);
    
    return check_ret;
  }
  
  BOOLEAN ext__f__check__logs(const CHARSTRING& log_file_path, const CHARSTRING& log_file_name, const CHARSTRING& content)
  {
    printf ("\n");
    char search_file_path[1024] = "find ";
    strcat(search_file_path, (const char *)log_file_path);
    strcat(search_file_path, " -name '");
    strcat(search_file_path, (const char *)log_file_name);
    strcat(search_file_path, "'");
    
    printf ("%s\n", search_file_path);
    FILE* pp = popen (search_file_path, "r");
    if (pp == NULL)
    {
      pclose(pp);
      return false;
    }
    printf ("Log checking ... \n\n");
    int flag = 0;
    memset( search_file_path, 0, 1024 );
    while ( fgets(search_file_path, 1024, pp) != NULL )
    {
      int path_len = strlen(search_file_path);
      search_file_path[path_len-1] = '\0'; // due to the 'fgets' will read the '\n', so the index of path_len-1 will be set to '\0'
      
      FILE* fp = fopen(search_file_path, "r");
      if (fp == NULL)
      {
        printf ("Open log file failed!\n\n");
        fclose(fp);
        return false;
      }
      fseek(fp, 0L, SEEK_END);
      long int file_len = ftell(fp);
      fseek(fp, 0L, SEEK_SET);
      char file_buf[file_len];
      fread(file_buf, file_len, 1, fp);
      fclose(fp);
      
      if (strstr(file_buf, (const char *)content) != NULL)
      {
        flag++;
        printf ("Log content was found in '%s'\n\n", search_file_path);
        printf ("... PASS\n");
      }
    }
    pclose(pp);
    if (!strcmp(search_file_path, ""))
    {
      printf ("Can not find log file.'\n\n");
      return false;
    }
    
    if (flag == 0)
    {
      printf ("Log file content check fail! There is no log file can match the content.\n");
      printf ("\n");
      return false;
    }
    printf ("\n");
    
    return true;
  }
  
  BOOLEAN ext__f__adfprov__config__change (const CHARSTRING& adfprov_config_path,
                                           const CHARSTRING& config_element, 
                                           const CHARSTRING& original_value, 
                                           const CHARSTRING& target_value)
  {
    FILE   *stream;
    char change_config_cmd[1024];
    char buf[1024];
    memset( buf, 0, sizeof(buf) );
    memset( change_config_cmd, 0, sizeof(change_config_cmd) );
    
    // backup the original config file
    strcat(change_config_cmd, "cp ");
    strcat(change_config_cmd, adfprov_config_path);
    strcat(change_config_cmd, " ");
    strcat(change_config_cmd, adfprov_config_path);
    strcat(change_config_cmd, ".bak");
    printf("Backup the original config file: %s \n", (const char *) change_config_cmd);
    stream = popen(change_config_cmd,"r"); 
    pclose( stream );   
    
    // sed the config file with change, output into tmp file
    // exp: sed 's#repairService</FrServiceBaseUri>.*$#repairService2</FrServiceBaseUri>#g' adf-provisioning.conf >adf-provisioning.conf.tmp
    memset( change_config_cmd, 0, sizeof(change_config_cmd) );
    strcat(change_config_cmd, "sed 's#");
    strcat(change_config_cmd, original_value);
    strcat(change_config_cmd, "</");
    strcat(change_config_cmd, config_element);
    strcat(change_config_cmd, ">.*$#");
    strcat(change_config_cmd, target_value);
    strcat(change_config_cmd, "</");
    strcat(change_config_cmd, config_element);
    strcat(change_config_cmd, ">#g' ");
    strcat(change_config_cmd, adfprov_config_path);
    strcat(change_config_cmd, " >");
    strcat(change_config_cmd, adfprov_config_path);
    strcat(change_config_cmd, ".tmp");
    printf("Change the config file: %s \n", (const char *) change_config_cmd);
    stream = popen(change_config_cmd,"r");   
    pclose( stream );  
    
    // replace config file with tmp file
    memset( change_config_cmd, 0, sizeof(change_config_cmd) );
    strcat(change_config_cmd, "cp ");
    strcat(change_config_cmd, adfprov_config_path);
    strcat(change_config_cmd, ".tmp ");
    strcat(change_config_cmd, adfprov_config_path);
    printf("Change the config file finished: %s \n", (const char *) change_config_cmd);
    stream = popen(change_config_cmd,"r");            
    pclose( stream );

    // clean up temp files
    memset( change_config_cmd, 0, sizeof(change_config_cmd) );
    strcat(change_config_cmd, "rm ");
    strcat(change_config_cmd, adfprov_config_path);
    strcat(change_config_cmd, ".bak ");
    strcat(change_config_cmd, adfprov_config_path);
    strcat(change_config_cmd, ".tmp ");
    stream = popen(change_config_cmd,"r");            
    pclose( stream );
    
    return true;
  }

}
