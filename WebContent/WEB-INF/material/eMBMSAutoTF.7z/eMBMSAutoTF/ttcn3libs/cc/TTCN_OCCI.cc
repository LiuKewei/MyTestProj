#include "TTCN_OCCI_obj.hh"
#include "TTCN_OCCI_wrapper.hh"
#include "TTCN_ORACLE_Interface.hh"
#include "TTCN3.hh"

static Database myDatabase;

namespace TTCN__ORACLE__Interface {

using namespace std;

BOOLEAN f__ttcn__occi__create(const CHARSTRING& p__ConnStr, const CHARSTRING& p__Username, const CHARSTRING& p__Passwd);
void f__ttcn__occi__terminate();
BOOLEAN f__ttcn__occi__selectSql(const CHARSTRING& p__sql, OCCI__Data__ResultSet& p__result);
OCCI__Data__ResultSet f_convert_occi2ttcn_result_set_to_ttcn(occi2ttcn_result_set p_in);

	BOOLEAN f__ttcn__occi__create(const CHARSTRING& p__ConnStr, const CHARSTRING& p__Username, const CHARSTRING& p__Passwd)
	{
		return myDatabase.connect(p__ConnStr, p__Username, p__Passwd);
	}

	void f__ttcn__occi__terminate()
	{
		myDatabase.disconnect();
	}

	BOOLEAN f__ttcn__occi__selectSql(const CHARSTRING& p__sql, OCCI__Data__ResultSet& p__result)
	{
		occi2ttcn_result_set myResult;
		
		bool res = myDatabase.selectSQL(p__sql, myResult);
				
		if(res)
		{
			p__result = f_convert_occi2ttcn_result_set_to_ttcn(myResult);
			
			cleanOcci2ttcn(myResult);
			
			return true;
		}
		
		return false;			
	}
	
	OCCI__Data__ResultSet f_convert_occi2ttcn_result_set_to_ttcn(occi2ttcn_result_set p_in)
	{
		OCCI__Data__ResultSet ttcnResultSet = OCCI__Data__ResultSet(NULL_VALUE);
	
		occi2ttcn_result_set::iterator occiResultSetItr;
				
		for( occiResultSetItr = p_in.begin(); occiResultSetItr < p_in.end(); occiResultSetItr++)
		{			
			occi2ttcn_result occiResult = *occiResultSetItr;
			occi2ttcn_result::iterator occiResultItr;
			OCCI__Data__Result ttcnResult = OCCI__Data__Result();
			int ttcnResultIdx = 0;
			
			for( occiResultItr = occiResult.begin(); occiResultItr < occiResult.end(); occiResultItr++)
			{
				if ( (*occiResultItr).val_type == TYPE_STR )
				{
					ttcnResult[ttcnResultIdx].str__val() = (*occiResultItr).val_.str_val;
				}
				else if ( (*occiResultItr).val_type == TYPE_FLOAT )
				{
					ttcnResult[ttcnResultIdx].float__val() = (*occiResultItr).val_.float_val;
				}
				else if ( (*occiResultItr).val_type == TYPE_INT )
				{
					ttcnResult[ttcnResultIdx].int__val() = (*occiResultItr).val_.int_val;
				}				
				else if ( (*occiResultItr).val_type == TYPE_NULL )
				{
					ttcnResult[ttcnResultIdx].null__val() = true;
				}
				else
				{

				}
				
				ttcnResultIdx++;
			}
			
			ttcnResultSet[ttcnResultSet.size_of()] = ttcnResult;
	
		}
				
		return ttcnResultSet;
		
	}
}






